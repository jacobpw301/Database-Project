-- phpMyAdmin SQL Dump
-- version 4.3.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 12, 2018 at 09:13 AM
-- Server version: 5.5.51-38.2
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `jcarman1_phpexample`
--

-- --------------------------------------------------------

--
-- Table structure for table `orderitems`
--

CREATE TABLE IF NOT EXISTS `orderitems` (
  `dborderitemid` int(11) NOT NULL,
  `dborderid` int(11) NOT NULL,
  `dbprodid` int(11) NOT NULL,
  `dborderitemprice` decimal(10,2) NOT NULL,
  `dborderitemnotes` char(55) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `orderitems`
--

INSERT INTO `orderitems` (`dborderitemid`, `dborderid`, `dbprodid`, `dborderitemprice`, `dborderitemnotes`) VALUES
(1, 1, 3, '22.95', ''),
(18, 5, 3, '22.95', ''),
(17, 5, 6, '2.66', ''),
(16, 5, 1, '15.55', ''),
(14, 5, 5, '1.56', ''),
(13, 5, 6, '2.66', ''),
(12, 5, 4, '9.95', ''),
(10, 5, 2, '12.35', ''),
(19, 7, 1, '15.55', 'Got a fever'),
(20, 7, 4, '7.95', 'Discount for nice smile'),
(23, 7, 5, '1.59', ''),
(24, 7, 3, '22.95', ''),
(25, 7, 4, '9.95', ''),
(26, 9, 3, '22.95', ''),
(27, 9, 1, '15.55', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orderitems`
--
ALTER TABLE `orderitems`
  ADD PRIMARY KEY (`dborderitemid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orderitems`
--
ALTER TABLE `orderitems`
  MODIFY `dborderitemid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=28;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
