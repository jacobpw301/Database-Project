-- phpMyAdmin SQL Dump
-- version 4.3.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 12, 2018 at 09:14 AM
-- Server version: 5.5.51-38.2
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `jcarman1_phpexample`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE IF NOT EXISTS `appointments` (
  `dbapptid` int(11) NOT NULL,
  `dbapptcustomer` int(11) NOT NULL,
  `dbappttech` int(11) NOT NULL,
  `dbapptdate` date NOT NULL,
  `dbappttime` varchar(6) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`dbapptid`, `dbapptcustomer`, `dbappttech`, `dbapptdate`, `dbappttime`) VALUES
(1, 1, 2, '2016-11-30', '1 PM'),
(23, 1, 1, '2017-02-20', '12 PM'),
(22, 3, 1, '2017-02-20', '11 AM'),
(18, 1, 1, '2017-02-17', '8 AM'),
(49, 48, 3, '2018-01-01', ''),
(48, 1, 2, '2017-12-20', ''),
(47, 3, 16, '2017-11-22', ''),
(50, 1, 3, '2017-12-13', ''),
(51, 1, 12, '2017-12-12', ''),
(52, 1, 1, '2016-03-26', ''),
(53, 2, 3, '2018-01-17', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`dbapptid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `dbapptid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=54;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
