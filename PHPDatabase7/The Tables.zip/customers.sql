-- phpMyAdmin SQL Dump
-- version 4.3.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 12, 2018 at 09:13 AM
-- Server version: 5.5.51-38.2
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `jcarman1_phpexample`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE IF NOT EXISTS `customers` (
  `dbcustid` int(11) NOT NULL,
  `dbcustname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `dbcustlastname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `dbcustusername` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `dbcustaddress` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `dbcustphone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `dbcustplan` int(11) NOT NULL,
  `dbcustpass` char(100) COLLATE utf8_unicode_ci NOT NULL,
  `dbcustsalt` char(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`dbcustid`, `dbcustname`, `dbcustlastname`, `dbcustusername`, `dbcustaddress`, `dbcustphone`, `dbcustplan`, `dbcustpass`, `dbcustsalt`) VALUES
(1, 'John Smith', 'Smith', 'johnsmith', '1234', '843-111-1111', 2, '$2a$07$vGKJyOqdH0x/ggi4EgRYVu9OefWECLV.rRx9FVVX.HTdZgPKLhI9a', '$2a$07$vGKJyOqdH0x/ggi4EgRYVx'),
(2, 'Bob', 'Jones', 'bobjones', 'Augusta', '843-222-2222', 2, '$2a$07$OyTGHNNr6TdgPFfdF991OuGcHcrgYIr/4Lj3jDEsM2MW2.bekI6t2', '$2a$07$OyTGHNNr6TdgPFfdF991Oz'),
(3, 'Wayne', 'Wayne', 'jackwayne', '1234', '843-333-3333', 3, '$2a$07$iwpqGNxwLASAhHVYUr/hsOuLhuBP7kBivbdnu.ShxMOgLesBG3URq', '$2a$07$iwpqGNxwLASAhHVYUr/hsb');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`dbcustid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `dbcustid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=54;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
