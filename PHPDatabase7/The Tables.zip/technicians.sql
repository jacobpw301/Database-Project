-- phpMyAdmin SQL Dump
-- version 4.3.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 12, 2018 at 09:13 AM
-- Server version: 5.5.51-38.2
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `jcarman1_phpexample`
--

-- --------------------------------------------------------

--
-- Table structure for table `technicians`
--

CREATE TABLE IF NOT EXISTS `technicians` (
  `dbtechid` int(11) NOT NULL,
  `dbtechname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `dbtechtitle` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `dbtechschedule` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `dbtechpay` decimal(8,2) NOT NULL,
  `dbtechusername` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `dbtechpass` char(100) COLLATE utf8_unicode_ci NOT NULL,
  `dbtechsalt` char(75) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `technicians`
--

INSERT INTO `technicians` (`dbtechid`, `dbtechname`, `dbtechtitle`, `dbtechschedule`, `dbtechpay`, `dbtechusername`, `dbtechpass`, `dbtechsalt`) VALUES
(1, 'Mr Technical', '1', 'm-f', '19.75', 'mrt', '$2y$12$lOROQqlSMVQ38btrphHfYuLOnjivVGOuSMDmmaw4ycKDtuNdWFbiK', ''),
(2, 'Basic Tech', '4', 'm-f', '15.50', 'basictech', '$2y$12$6EUCu.6Da3E2IDhtiVnbBuC0yvujFvsbe0572/AgMF1DyHZJhAaH.', ''),
(3, 'New Guy', '3', 'mt', '19.75', 'mrt', '$2y$12$4M2odi8BgAhOWu2CalBZbueV.STxFNLRfugV0ogMHKrPDxLlvBhvu', ''),
(12, 'Techie', '4', 'mwf', '14.50', 'techie', '$2y$12$xNC9aGK63ohlxPj/3ViL/uRcF6vGAuA6MrktiJt.QMNA5O4cpNhTW', ''),
(30, 'z', '2', 'z', '19.75', 'z', '$2y$12$r79E2ItbqG.i/sQtxWPR8OThEhuz2Pfbolm4uMWv9v5kQmiE6IbDe', ''),
(29, 'q', '5', 'q', '14.50', 'q', '$2y$12$zRQlbwFf6zEanonKjYosRes3MP/G9kdLRWHCue13nFWVS7rI6sWYa', ''),
(34, 'a', '1', 'a', '12.50', 'a', '$2y$12$zVA4lIii3m0eeQVMMzocOeDzuZRTd9QWrqk.ENZ2/s8GmMDRBGrkK', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `technicians`
--
ALTER TABLE `technicians`
  ADD PRIMARY KEY (`dbtechid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `technicians`
--
ALTER TABLE `technicians`
  MODIFY `dbtechid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=35;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
