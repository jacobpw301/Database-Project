-- phpMyAdmin SQL Dump
-- version 4.3.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 12, 2018 at 09:13 AM
-- Server version: 5.5.51-38.2
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `jcarman1_phpexample`
--

-- --------------------------------------------------------

--
-- Table structure for table `techtitle`
--

CREATE TABLE IF NOT EXISTS `techtitle` (
  `dbtechtitleid` int(11) NOT NULL,
  `dbtechtitlename` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `techtitle`
--

INSERT INTO `techtitle` (`dbtechtitleid`, `dbtechtitlename`) VALUES
(1, 'Manager'),
(2, 'Supervisor'),
(3, 'Front Desk'),
(4, 'Technician'),
(5, 'Assistant');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `techtitle`
--
ALTER TABLE `techtitle`
  ADD PRIMARY KEY (`dbtechtitleid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `techtitle`
--
ALTER TABLE `techtitle`
  MODIFY `dbtechtitleid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
